
The react implementation is the component Exp.jsx this component uses the files inside the /src/assets/... (index.html, main.js, style.css) and the public folder for work. I hope this is a good solution.


Also the Experience.jsx and Fingerprint.jsx components are my attempts to port my native Three.js code to React Three Fiber. Since I'm not very familiar with it, I don't think I can implement it this way.
